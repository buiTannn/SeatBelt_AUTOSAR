/*
 * File: SeatBelt_types.h
 *
 * Code generated for Simulink model 'SeatBelt'.
 *
 * Model version                  : 1.41
 * Simulink Coder version         : 24.1 (R2024a) 19-Nov-2023
 * C/C++ source code generated on : Mon Jul 14 23:49:04 2025
 *
 * Target selection: autosar.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef SeatBelt_types_h_
#define SeatBelt_types_h_
#include "Rte_Type.h"
#endif                                 /* SeatBelt_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
