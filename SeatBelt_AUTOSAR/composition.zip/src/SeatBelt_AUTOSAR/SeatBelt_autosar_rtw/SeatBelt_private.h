/*
 * File: SeatBelt_private.h
 *
 * Code generated for Simulink model 'SeatBelt'.
 *
 * Model version                  : 1.41
 * Simulink Coder version         : 24.1 (R2024a) 19-Nov-2023
 * C/C++ source code generated on : Mon Jul 14 23:49:04 2025
 *
 * Target selection: autosar.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef SeatBelt_private_h_
#define SeatBelt_private_h_
#include "Platform_Types.h"
#include "SeatBelt_types.h"
#endif                                 /* SeatBelt_private_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
