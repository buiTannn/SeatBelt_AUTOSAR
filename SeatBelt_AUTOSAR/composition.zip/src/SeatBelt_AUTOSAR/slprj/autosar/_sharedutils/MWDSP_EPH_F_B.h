/*
 * File: MWDSP_EPH_F_B.h
 *
 * Code generated for Simulink model 'SetBelt'.
 *
 * Model version                  : 1.39
 * Simulink Coder version         : 24.1 (R2024a) 19-Nov-2023
 * C/C++ source code generated on : Mon Jul 14 22:03:58 2025
 */

#ifndef MWDSP_EPH_F_B_h_
#define MWDSP_EPH_F_B_h_
#include "Platform_Types.h"

extern uint32 MWDSP_EPH_F_B(boolean evt, uint32 *sta);

#endif                                 /* MWDSP_EPH_F_B_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
