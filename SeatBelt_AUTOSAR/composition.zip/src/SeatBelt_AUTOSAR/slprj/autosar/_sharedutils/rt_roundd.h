/*
 * File: rt_roundd.h
 *
 * Code generated for Simulink model 'SetBelt'.
 *
 * Model version                  : 1.29
 * Simulink Coder version         : 24.1 (R2024a) 19-Nov-2023
 * C/C++ source code generated on : Sun Jul 13 12:48:42 2025
 */

#ifndef rt_roundd_h_
#define rt_roundd_h_
#include "Platform_Types.h"

extern float64 rt_roundd(float64 u);

#endif                                 /* rt_roundd_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
