/*
 * File: GetStatus_types.h
 *
 * Code generated for Simulink model 'GetStatus'.
 *
 * Model version                  : 1.12
 * Simulink Coder version         : 24.1 (R2024a) 19-Nov-2023
 * C/C++ source code generated on : Mon Jul 14 23:46:02 2025
 *
 * Target selection: autosar.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef GetStatus_types_h_
#define GetStatus_types_h_
#endif                                 /* GetStatus_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
