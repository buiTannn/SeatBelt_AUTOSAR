/*
 * File: GetStatus_private.h
 *
 * Code generated for Simulink model 'GetStatus'.
 *
 * Model version                  : 1.11
 * Simulink Coder version         : 24.1 (R2024a) 19-Nov-2023
 * C/C++ source code generated on : Mon Jul 14 22:59:03 2025
 *
 * Target selection: autosar.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef GetStatus_private_h_
#define GetStatus_private_h_
#include "Platform_Types.h"
#include "GetStatus_types.h"
#endif                                 /* GetStatus_private_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
