/*
 * File: SetBelt_private.h
 *
 * Code generated for Simulink model 'SetBelt'.
 *
 * Model version                  : 1.40
 * Simulink Coder version         : 24.1 (R2024a) 19-Nov-2023
 * C/C++ source code generated on : Mon Jul 14 22:59:24 2025
 *
 * Target selection: autosar.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef SetBelt_private_h_
#define SetBelt_private_h_
#include "Platform_Types.h"
#include "SetBelt_types.h"
#endif                                 /* SetBelt_private_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
